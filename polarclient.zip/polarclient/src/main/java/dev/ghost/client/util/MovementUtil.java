// language: Java, file: MovementUtil.java
// Movement helpers: input direction → world velocity, on-ground check, strafe
package dev.ghost.client.util;

import net.minecraft.client.Minecraft;
import net.minecraft.util.MathHelper;

public final class MovementUtil {

    private static final Minecraft mc = Minecraft.getMinecraft();

    private MovementUtil() {}

    /** Is the player pressing any movement key? */
    public static boolean isMoving() {
        return mc.thePlayer.moveForward != 0 || mc.thePlayer.moveStrafing != 0;
    }

    /**
     * Apply horizontal velocity in the direction the player is pressing,
     * scaled to `speed`.  Uses rotationYaw so the vector follows the
     * camera, matching what legit sprint motion looks like to the server.
     */
    public static void setSpeed(double speed) {
        if (!isMoving()) return;

        float yaw   = mc.thePlayer.rotationYaw;
        float fwd   = mc.thePlayer.moveForward;
        float str   = mc.thePlayer.moveStrafing;

        // Normalise diagonal input
        double len = MathHelper.sqrt_double(fwd * fwd + str * str);
        if (len == 0) return;
        fwd /= len; str /= len;

        double rad = Math.toRadians(yaw);
        double vx  = -MathHelper.sin((float) rad) * fwd * speed
                   +  MathHelper.cos((float) rad) * str * speed;
        double vz  =  MathHelper.cos((float) rad) * fwd * speed
                   +  MathHelper.sin((float) rad) * str * speed;

        mc.thePlayer.motionX = vx;
        mc.thePlayer.motionZ = vz;
    }

    /** Current horizontal speed (magnitude of XZ motion vector). */
    public static double getHorizontalSpeed() {
        double mx = mc.thePlayer.motionX;
        double mz = mc.thePlayer.motionZ;
        return MathHelper.sqrt_double(mx * mx + mz * mz);
    }
}
