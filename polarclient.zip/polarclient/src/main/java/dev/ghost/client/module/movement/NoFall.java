// language: Java, file: NoFall.java
// Polar bypass: send a single C03PacketPlayer with onGround=true one tick
// before the player lands.  Polar's fall-damage check fires when it sees
// onGround flip true while fallDistance > 3.  Sending the flag early resets
// fallDistance on the server side before the actual landing packet arrives,
// so the server never applies damage.
// Threshold of 2.5 gives one-tick lead time even at terminal velocity.
package dev.ghost.client.module.movement;

import dev.ghost.client.module.Module;
import net.minecraft.network.play.client.C03PacketPlayer;
import org.lwjgl.input.Keyboard;

public class NoFall extends Module {

    private static final float FALL_THRESHOLD = 2.5f; // start spoofing above this fall distance

    private boolean spoofSent = false;

    public NoFall() {
        super("NoFall", Category.MOVEMENT, Keyboard.KEY_NONE);
    }

    @Override
    public void onTick() {
        if (!nullCheck()) return;

        float fall = mc.thePlayer.fallDistance;

        if (fall >= FALL_THRESHOLD && !spoofSent) {
            // Send early ground packet — resets server fallDistance to 0
            mc.thePlayer.sendQueue.addToSendQueue(
                new C03PacketPlayer(true));
            spoofSent = true;
        }

        // Reset flag when genuinely airborne again
        if (mc.thePlayer.motionY > 0 || mc.thePlayer.onGround) {
            spoofSent = false;
        }
    }
}
