// language: Java, file: ModuleManager.java
// Registers modules, routes TickEvent and RenderWorldLastEvent to each
package dev.ghost.client.manager;

import dev.ghost.client.module.Module;
import dev.ghost.client.module.combat.KillAura;
import dev.ghost.client.module.combat.AntiKB;
import dev.ghost.client.module.movement.Fly;
import dev.ghost.client.module.movement.Speed;
import dev.ghost.client.module.movement.NoFall;
import dev.ghost.client.module.render.ESP;
import dev.ghost.client.module.misc.Timer;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ModuleManager {

    private final List<Module> modules = new ArrayList<>();

    public void registerAll() {
        modules.add(new KillAura());
        modules.add(new AntiKB());
        modules.add(new Fly());
        modules.add(new Speed());
        modules.add(new NoFall());
        modules.add(new ESP());
        modules.add(new Timer());
    }

    @SubscribeEvent
    public void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.START) return;
        for (Module m : modules) {
            if (m.isEnabled()) m.onTick();
        }
    }

    @SubscribeEvent
    public void onRenderWorld(RenderWorldLastEvent event) {
        for (Module m : modules) {
            if (m.isEnabled()) m.onRender(event.partialTicks);
        }
    }

    public List<Module> getModules() {
        return Collections.unmodifiableList(modules);
    }

    @SuppressWarnings("unchecked")
    public <T extends Module> T getModule(Class<T> clazz) {
        return (T) modules.stream()
                          .filter(m -> m.getClass() == clazz)
                          .findFirst()
                          .orElse(null);
    }
}
