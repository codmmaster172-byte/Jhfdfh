// language: Java, file: Timer.java
// Adjusts Minecraft's internal tick rate by writing mc.timer.timerSpeed.
// Polar detects timer hacks via packet frequency analysis: if the server
// receives movement packets faster than 20/s it flags "PacketFrequency".
// SAFE_SPEED is kept at 1.08 (~8 % speedup) — enough for a measurable
// advantage while staying under Polar's ~1.15 detection threshold.
// Uses reflection to access the obfuscated field; SRG name field_74278_d
// maps to "timerSpeed" in MCP stable_20.  If the field name fails (e.g.
// running with a different mapping), we fall back to SRG silently.
package dev.ghost.client.module.misc;

import dev.ghost.client.module.Module;
import net.minecraft.util.Timer;
import org.lwjgl.input.Keyboard;

import java.lang.reflect.Field;

public class Timer extends Module {

    private static final float SAFE_SPEED   = 1.08f;
    private static final float NORMAL_SPEED = 1.00f;

    private Field timerSpeedField;

    public Timer() {
        super("Timer", Category.MISC, Keyboard.KEY_NONE);
        timerSpeedField = resolveField();
    }

    @Override
    public void onEnable() {
        setTimerSpeed(SAFE_SPEED);
    }

    @Override
    public void onDisable() {
        setTimerSpeed(NORMAL_SPEED);
    }

    // ── Field resolution ──────────────────────────────────────────────────────

    /** Try mapped name, then SRG name, then enumerate all float fields. */
    private Field resolveField() {
        String[] candidates = {"timerSpeed", "field_74278_d"};
        for (String name : candidates) {
            try {
                Field f = Timer.class.getDeclaredField(name);
                f.setAccessible(true);
                return f;
            } catch (NoSuchFieldException ignored) {}
        }
        // Fallback: find first float field (timerSpeed is the only float in Timer)
        for (Field f : Timer.class.getDeclaredFields()) {
            if (f.getType() == float.class) {
                f.setAccessible(true);
                return f;
            }
        }
        return null; // will no-op gracefully
    }

    private void setTimerSpeed(float speed) {
        if (timerSpeedField == null) return;
        try {
            timerSpeedField.set(mc.timer, speed);
        } catch (IllegalAccessException e) {
            // silently swallow — timer stays at last value
        }
    }
}
