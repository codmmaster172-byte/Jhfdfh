// language: Java, file: AntiKB.java
// Polar bypass: zero-out horizontal knockback motion on the tick we receive a hit.
// Vertical (upward) component is kept so fall-damage accounting stays consistent.
// Complete removal flags "AntiKnockback" on strict servers; reduce to 0.15 factor
// (85 % reduction) to blend under the detection threshold.
package dev.ghost.client.module.combat;

import dev.ghost.client.module.Module;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Keyboard;

public class AntiKB extends Module {

    /** Fraction of knockback to KEEP (0 = full cancel, 1 = no change). */
    private static final double KEEP_FACTOR = 0.15;

    /** True for the single tick after we absorb a hit. */
    private boolean cancelNextMotion = false;

    public AntiKB() {
        super("AntiKB", Category.COMBAT, Keyboard.KEY_NONE);
    }

    @Override
    public void onEnable()  { MinecraftForge.EVENT_BUS.register(this); }
    @Override
    public void onDisable() { MinecraftForge.EVENT_BUS.unregister(this); }

    /**
     * Forge fires TickEvent every game tick.  We hook the END phase so
     * all packet-applied velocity changes (including knockback) are
     * already in motionX/Z by the time we reduce them.
     */
    @SubscribeEvent
    public void onTick(TickEvent.PlayerTickEvent event) {
        if (!isEnabled()) return;
        if (event.phase != TickEvent.Phase.END) return;
        if (!nullCheck()) return;
        if (mc.thePlayer.hurtTime <= 0) return;    // not in a hurt frame

        // Reduce horizontal knockback; leave vertical alone
        mc.thePlayer.motionX *= KEEP_FACTOR;
        mc.thePlayer.motionZ *= KEEP_FACTOR;
    }

    // nullCheck helper works on the parent Module's mc reference
    private boolean nullCheck() {
        return mc.thePlayer != null && mc.theWorld != null;
    }
}
