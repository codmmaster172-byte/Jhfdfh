// language: Java, file: KillAura.java
// Polar bypass notes per technique:
//   GCD fix      — prevents "InvalidRotation" flag (rotation delta not on mouse grid)
//   Smooth aim   — prevents "AimAssist" / "RotationSpeed" flags (snap aim)
//   Reach ≤ 3.0  — Polar flags reach > 3.1; we use 3.0 to stay under
//   Wall check   — prevents attacking through blocks (flags "Hitbox")
//   Swing timing — swing packet BEFORE use packet, mimics legit hand animation
//   Post-tick    — rotations applied in the same tick as the attack, not ahead
package dev.ghost.client.module.combat;

import dev.ghost.client.module.Module;
import dev.ghost.client.util.RotationUtil;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.network.play.client.C02PacketUseEntity;
import net.minecraft.network.play.client.C0APacketAnimation;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.Vec3;
import org.lwjgl.input.Keyboard;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class KillAura extends Module {

    // Tunable parameters ─────────────────────────────────────────────────────
    private final float  REACH       = 3.0f;   // blocks; Polar flags > 3.1
    private final float  AIM_SPEED   = 10.0f;  // deg/tick; >25 flags RotationSpeed
    private final int    CPS_MIN     = 8;       // clicks per second min
    private final int    CPS_MAX     = 12;      // clicks per second max
    // ─────────────────────────────────────────────────────────────────────────

    private float currentYaw;
    private float currentPitch;
    private int   ticksSinceAttack = 0;
    private int   attackInterval;  // ticks between attacks, derived from CPS

    public KillAura() {
        super("KillAura", Category.COMBAT, Keyboard.KEY_R);
        randomiseInterval();
    }

    @Override
    public void onEnable() {
        currentYaw   = mc.thePlayer.rotationYaw;
        currentPitch = mc.thePlayer.rotationPitch;
        randomiseInterval();
    }

    @Override
    public void onTick() {
        if (!nullCheck()) return;

        EntityLivingBase target = getNearestTarget();
        if (target == null) return;

        // ── 1. Compute ideal angles ───────────────────────────────────────
        float[] ideal = RotationUtil.getRotationsTo(target);

        // ── 2. Smooth + GCD-fix the rotation ─────────────────────────────
        float[] next = RotationUtil.smoothRotation(
                currentYaw, currentPitch,
                ideal[0],   ideal[1],
                AIM_SPEED
        );
        currentYaw   = next[0];
        currentPitch = next[1];

        // Apply to player head (server-side rotation is sent via C03 by MC itself)
        mc.thePlayer.rotationYaw      = currentYaw;
        mc.thePlayer.rotationPitch    = currentPitch;
        mc.thePlayer.rotationYawHead  = currentYaw;
        mc.thePlayer.renderYawOffset  = currentYaw;

        // ── 3. Attack on interval ─────────────────────────────────────────
        ticksSinceAttack++;
        if (ticksSinceAttack >= attackInterval) {
            ticksSinceAttack = 0;
            randomiseInterval();

            // Wall-check: can we trace a line from eye to target eye?
            if (!canSeeTarget(target)) return;

            // Swing first (matches legit client: animation before damage packet)
            mc.thePlayer.sendQueue.addToSendQueue(new C0APacketAnimation());

            // Attack packet
            mc.thePlayer.sendQueue.addToSendQueue(
                    new C02PacketUseEntity(target, C02PacketUseEntity.Action.ATTACK));

            // Hurt the entity client-side so the arm swings visually
            mc.thePlayer.swingItem();
        }
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private EntityLivingBase getNearestTarget() {
        List<EntityLivingBase> candidates = new ArrayList<>();

        for (Entity e : mc.theWorld.loadedEntityList) {
            if (!(e instanceof EntityLivingBase)) continue;
            EntityLivingBase living = (EntityLivingBase) e;
            if (living == mc.thePlayer)       continue; // skip self
            if (living.isDead)                continue; // skip dead
            if (living.getHealth() <= 0)      continue;
            if (!(living instanceof EntityPlayer)) continue; // players only
            if (mc.thePlayer.getDistanceToEntity(living) > REACH) continue;
            candidates.add(living);
        }

        if (candidates.isEmpty()) return null;

        candidates.sort(Comparator.comparingDouble(
                e -> mc.thePlayer.getDistanceToEntity(e)));
        return candidates.get(0);
    }

    /**
     * Raycast from player eyes to target eyes.
     * Returns false if a solid block interrupts the line — attacking through
     * blocks is one of Polar's easier flags to trigger.
     */
    private boolean canSeeTarget(EntityLivingBase target) {
        Vec3 eyes   = mc.thePlayer.getPositionEyes(1.0f);
        Vec3 tEyes  = new Vec3(target.posX,
                               target.posY + target.getEyeHeight(),
                               target.posZ);
        MovingObjectPosition mop = mc.theWorld.rayTraceBlocks(eyes, tEyes);
        return mop == null || mop.typeOfHit == MovingObjectPosition.MovingObjectType.MISS;
    }

    /** Randomise attack interval within [CPS_MIN, CPS_MAX] ticks. */
    private void randomiseInterval() {
        // CPS → ticks: 20 ticks/s ÷ CPS
        int tMin = 20 / CPS_MAX; // fewer ticks = more CPS
        int tMax = 20 / CPS_MIN;
        attackInterval = tMin + (int)(Math.random() * (tMax - tMin + 1));
    }
}
