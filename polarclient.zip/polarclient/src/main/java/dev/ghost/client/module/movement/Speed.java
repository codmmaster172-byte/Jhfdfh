// language: Java, file: Speed.java
// Polar bypass: bunny-hop speed.
// Polar's speed check validates each move packet against an expected distance
// derived from the previous ground/air state.  The maximum allowed speed for
// a single air tick after a jump is ~0.49 b/t (with sprint modifier).
// Bunny-hop works by jumping the instant we touch ground; the first air tick
// inherits legit jump momentum so each individual packet stays under the flag
// threshold even though sustained speed is higher than walking.
// Horizontal speed is clamped to SAFE_SPEED to keep each packet under the
// per-tick threshold Polar uses.
package dev.ghost.client.module.movement;

import dev.ghost.client.module.Module;
import dev.ghost.client.util.MovementUtil;
import org.lwjgl.input.Keyboard;

public class Speed extends Module {

    // 0.49 b/t is the first-air-tick cap Polar enforces for sprinting players.
    // We stay at 0.45 to leave headroom for ping jitter.
    private static final double SAFE_SPEED = 0.45;

    /** Whether we were on the ground last tick (edge detection for jump timing). */
    private boolean wasOnGround = false;

    public Speed() {
        super("Speed", Category.MOVEMENT, Keyboard.KEY_V);
    }

    @Override
    public void onDisable() {
        // Bleed off excess speed when toggled off so the next position packet
        // doesn't look like a teleport to the server.
        if (nullCheck()) {
            mc.thePlayer.motionX *= 0.1;
            mc.thePlayer.motionZ *= 0.1;
        }
    }

    @Override
    public void onTick() {
        if (!nullCheck()) return;
        if (!MovementUtil.isMoving()) return;

        boolean onGround = mc.thePlayer.onGround;

        if (onGround) {
            // Jump the moment we land — this initiates the bunny-hop cycle.
            mc.thePlayer.jump();
        }

        // In the air: apply horizontal speed
        if (!onGround) {
            MovementUtil.setSpeed(SAFE_SPEED);

            // Add a tiny random noise (±0.004) so repeated packets don't have
            // the identical delta Polar's pattern checker looks for.
            double noise = (Math.random() - 0.5) * 0.008;
            mc.thePlayer.motionX += noise;
            mc.thePlayer.motionZ += noise;
        }

        wasOnGround = onGround;
    }
}
