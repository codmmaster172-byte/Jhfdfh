// language: Java, file: Module.java
// Abstract base for every module — holds name, category, keybind, enabled state
package dev.ghost.client.module;

import dev.ghost.client.GhostClient;
import net.minecraft.client.Minecraft;

public abstract class Module {

    public enum Category { COMBAT, MOVEMENT, RENDER, MISC }

    protected final Minecraft mc = Minecraft.getMinecraft();

    private final String   name;
    private final Category category;
    private int            key;
    private boolean        enabled;

    public Module(String name, Category category, int key) {
        this.name     = name;
        this.category = category;
        this.key      = key;
        this.enabled  = false;
    }

    /** Called by Forge events — only runs when enabled */
    public void onTick() {}
    public void onRender(float partialTicks) {}
    public void onEnable()  {}
    public void onDisable() {}

    public void toggle() {
        enabled = !enabled;
        if (enabled) onEnable(); else onDisable();
    }

    public boolean isEnabled()        { return enabled; }
    public void    setEnabled(boolean b) {
        if (b != enabled) toggle();
    }

    public String   getName()     { return name; }
    public Category getCategory() { return category; }
    public int      getKey()      { return key; }
    public void     setKey(int k) { key = k; }

    /** Helper: is the local player and world present? */
    protected boolean nullCheck() {
        return mc.thePlayer != null && mc.theWorld != null;
    }
}
