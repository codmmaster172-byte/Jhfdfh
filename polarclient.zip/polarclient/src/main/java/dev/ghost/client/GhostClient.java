// language: Java, file: GhostClient.java, target: Forge 1.8.9 (stable_20)
// Entry point — initialises module manager, event bus, keybind handler
package dev.ghost.client;

import dev.ghost.client.manager.ModuleManager;
import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.KeyBinding;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import org.lwjgl.input.Keyboard;

@Mod(modid = GhostClient.MODID, version = GhostClient.VERSION, clientSideOnly = true)
public class GhostClient {

    public static final String MODID   = "ghostclient";
    public static final String VERSION = "1.0-SNAPSHOT";

    /** Singleton — access via GhostClient.INSTANCE */
    @Mod.Instance(MODID)
    public static GhostClient INSTANCE;

    public static ModuleManager moduleManager;
    public static Minecraft mc = Minecraft.getMinecraft();

    /** GUI open key: INSERT by default */
    public static final KeyBinding OPEN_GUI = new KeyBinding("Open Ghost GUI", Keyboard.KEY_INSERT, "GhostClient");

    @EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        moduleManager = new ModuleManager();
    }

    @EventHandler
    public void init(FMLInitializationEvent event) {
        MinecraftForge.EVENT_BUS.register(this);
        MinecraftForge.EVENT_BUS.register(moduleManager);
        moduleManager.registerAll();
    }

    @SubscribeEvent
    public void onKeyInput(InputEvent.KeyInputEvent event) {
        // Toggle each module whose keybind was pressed
        moduleManager.getModules().forEach(mod -> {
            if (mod.getKey() != Keyboard.KEY_NONE && Keyboard.isKeyDown(mod.getKey())) {
                // debounce: only toggle on key-down edge
                mod.toggle();
            }
        });
    }
}
