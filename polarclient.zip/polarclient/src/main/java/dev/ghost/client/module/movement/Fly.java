// language: Java, file: Fly.java
// Polar bypass strategy:
//   "ClipFly" mode — move with direct Y velocity but send a grounded packet
//   every GROUND_SPOOF_INTERVAL ticks so the server sees periodic ground contact.
//   Polar tracks the player's Y-history; a sudden upward clip without a prior
//   ground packet triggers "InvalidMove_Fly".  Spoofing ground resets that check.
//   Small downward nudge each tick (GRAVITY_STUB) keeps Polar's gravity check happy.
//
//   Mode 0 = CLIP_FLY   (fastest, works on most Polar configs)
//   Mode 1 = GLIDE_FLY  (slower, harder to detect, for strict configs)
package dev.ghost.client.module.movement;

import dev.ghost.client.module.Module;
import dev.ghost.client.util.MovementUtil;
import net.minecraft.network.play.client.C03PacketPlayer;
import org.lwjgl.input.Keyboard;

public class Fly extends Module {

    // ── Tunables ─────────────────────────────────────────────────────────────
    private static final double FLY_SPEED            = 0.55;  // blocks/tick horizontal
    private static final double FLY_SPEED_VERTICAL   = 0.35;  // blocks/tick up/down
    private static final double GRAVITY_STUB         = -0.01; // tiny downward nudge, keeps gravity check alive
    private static final int    GROUND_SPOOF_INTERVAL = 10;   // ticks between fake ground packets
    private static final int    MODE                  = 0;    // 0 = clip, 1 = glide
    // ─────────────────────────────────────────────────────────────────────────

    private int groundSpoofTimer = 0;

    public Fly() {
        super("Fly", Category.MOVEMENT, Keyboard.KEY_F);
    }

    @Override
    public void onEnable() {
        if (!nullCheck()) return;
        mc.thePlayer.capabilities.isFlying = false; // let us handle motion manually
        groundSpoofTimer = 0;
    }

    @Override
    public void onDisable() {
        if (!nullCheck()) return;
        mc.thePlayer.capabilities.isFlying = false;
        mc.thePlayer.motionY = 0;
    }

    @Override
    public void onTick() {
        if (!nullCheck()) return;

        // Cancel vanilla gravity / acceleration
        mc.thePlayer.fallDistance  = 0f;
        mc.thePlayer.motionY       = GRAVITY_STUB;
        mc.thePlayer.onGround      = false;

        if (MODE == 0) clipFly();
        else           glideFly();

        // ── Ground spoof ──────────────────────────────────────────────────
        groundSpoofTimer++;
        if (groundSpoofTimer >= GROUND_SPOOF_INTERVAL) {
            groundSpoofTimer = 0;
            // Send an onGround=true packet without actually touching the ground.
            // This resets Polar's Y-history window, preventing the cumulative
            // flight-distance check from accumulating to the flag threshold.
            mc.thePlayer.sendQueue.addToSendQueue(
                new C03PacketPlayer(true));
        }
    }

    // ─────────────────────────────────────────────────────────────────────────

    private void clipFly() {
        MovementUtil.setSpeed(FLY_SPEED);

        if (mc.gameSettings.keyBindJump.isKeyDown()) {
            mc.thePlayer.motionY = FLY_SPEED_VERTICAL;
        } else if (mc.gameSettings.keyBindSneak.isKeyDown()) {
            mc.thePlayer.motionY = -FLY_SPEED_VERTICAL;
        }
    }

    private void glideFly() {
        // Glide: horizontal at half speed, Y drifts with key input,
        // falls back to GRAVITY_STUB when no vertical key held.
        MovementUtil.setSpeed(FLY_SPEED * 0.5);

        if (mc.gameSettings.keyBindJump.isKeyDown()) {
            mc.thePlayer.motionY += 0.04;
            if (mc.thePlayer.motionY > FLY_SPEED_VERTICAL * 0.6)
                mc.thePlayer.motionY = FLY_SPEED_VERTICAL * 0.6;
        } else if (mc.gameSettings.keyBindSneak.isKeyDown()) {
            mc.thePlayer.motionY -= 0.04;
            if (mc.thePlayer.motionY < -FLY_SPEED_VERTICAL * 0.6)
                mc.thePlayer.motionY = -FLY_SPEED_VERTICAL * 0.6;
        }
    }
}
