// language: Java, file: ESP.java
// Renders a wireframe AABB box around every EntityPlayer in the world.
// No bypass needed — pure client-side render, server sees nothing.
// GL depth test is disabled so boxes show through terrain.
package dev.ghost.client.module.render;

import dev.ghost.client.module.Module;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderGlobal;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.AxisAlignedBB;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.GL11;

public class ESP extends Module {

    public ESP() {
        super("ESP", Category.RENDER, Keyboard.KEY_NONE);
    }

    @Override
    public void onRender(float partialTicks) {
        if (!nullCheck()) return;

        GlStateManager.pushMatrix();
        GlStateManager.disableTexture2D();
        GlStateManager.disableLighting();
        GlStateManager.disableDepth();      // draw through walls
        GlStateManager.enableBlend();
        GlStateManager.blendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        GlStateManager.glLineWidth(1.5f);

        // Camera interpolated origin — subtract render position so boxes
        // sit exactly on the entity regardless of partial tick
        double rpX = mc.getRenderManager().viewerPosX;
        double rpY = mc.getRenderManager().viewerPosY;
        double rpZ = mc.getRenderManager().viewerPosZ;

        for (Object obj : mc.theWorld.playerEntities) {
            EntityPlayer player = (EntityPlayer) obj;
            if (player == mc.thePlayer) continue;
            if (player.isDead) continue;

            // Interpolated position for this partial tick
            double x = player.prevPosX + (player.posX - player.prevPosX) * partialTicks - rpX;
            double y = player.prevPosY + (player.posY - player.prevPosY) * partialTicks - rpY;
            double z = player.prevPosZ + (player.posZ - player.prevPosZ) * partialTicks - rpZ;

            AxisAlignedBB bb = player.getEntityBoundingBox();
            double w = (bb.maxX - bb.minX) / 2.0;
            double h =  bb.maxY - bb.minY;

            // Cyan box for other players
            GlStateManager.color(0f, 1f, 1f, 0.7f);

            AxisAlignedBB render = new AxisAlignedBB(
                x - w, y,     z - w,
                x + w, y + h, z + w
            );
            RenderGlobal.drawSelectionBoundingBox(render);
        }

        GlStateManager.enableDepth();
        GlStateManager.enableTexture2D();
        GlStateManager.enableLighting();
        GlStateManager.disableBlend();
        GlStateManager.popMatrix();
    }
}
