// language: Java, file: RotationUtil.java
// GCD mouse-fix + smooth rotation interpolation
// Polar checks that yaw/pitch deltas align with real mouse sensitivity quanta.
// Sending rotations that land off-grid triggers the "invalid rotation" flag.
package dev.ghost.client.util;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.util.MathHelper;

public final class RotationUtil {

    private static final Minecraft mc = Minecraft.getMinecraft();

    private RotationUtil() {}

    // ── GCD fix ────────────────────────────────────────────────────────────

    /**
     * Compute the effective mouse-input quantum for the current sensitivity.
     * Real mouse moves produce yaw/pitch deltas that are integer multiples of
     * this value.  Polar flags when that invariant breaks.
     * Derivation mirrors Minecraft's MouseHelper: sensitivity ∈ [0,1] →
     *   f = sens * 0.6 + 0.2;  gcd ≈ f³ * 1.2
     */
    public static double computeGCD() {
        double sens = mc.gameSettings.mouseSensitivity; // already 0–1 in MC internals
        double f    = sens * 0.6 + 0.2;
        return f * f * f * 1.2;
    }

    /**
     * Snap (targetYaw, targetPitch) to the nearest GCD grid relative to
     * (currentYaw, currentPitch) so the delta looks like a legitimate mouse move.
     * Returns float[]{snappedYaw, snappedPitch}.
     */
    public static float[] gcdFix(float targetYaw, float targetPitch,
                                  float currentYaw, float currentPitch) {
        double gcd = computeGCD();
        if (gcd <= 0) return new float[]{targetYaw, targetPitch};

        double deltaYaw   = targetYaw   - currentYaw;
        double deltaPitch = targetPitch - currentPitch;

        // Round to nearest GCD multiple
        deltaYaw   = Math.round(deltaYaw   / gcd) * gcd;
        deltaPitch = Math.round(deltaPitch / gcd) * gcd;

        return new float[]{
            (float)(currentYaw   + deltaYaw),
            MathHelper.clamp_float((float)(currentPitch + deltaPitch), -90f, 90f)
        };
    }

    // ── Smooth rotation ────────────────────────────────────────────────────

    /**
     * Move (currentYaw, currentPitch) toward (targetYaw, targetPitch) by at
     * most `speed` degrees/tick, then apply GCD fix.
     * speed ≈ 8–15 passes Polar; >25 looks like snap-aim and flags.
     */
    public static float[] smoothRotation(float currentYaw, float currentPitch,
                                          float targetYaw,  float targetPitch,
                                          float speed) {
        float dYaw   = wrapDegrees(targetYaw   - currentYaw);
        float dPitch = wrapDegrees(targetPitch - currentPitch);

        float stepYaw   = MathHelper.clamp_float(dYaw,   -speed, speed);
        float stepPitch = MathHelper.clamp_float(dPitch, -speed, speed);

        float newYaw   = currentYaw   + stepYaw;
        float newPitch = currentPitch + stepPitch;

        return gcdFix(newYaw, newPitch, currentYaw, currentPitch);
    }

    // ── Angle to entity ────────────────────────────────────────────────────

    /** Compute ideal [yaw, pitch] to look at the given entity's eye height. */
    public static float[] getRotationsTo(Entity target) {
        double dx = target.posX - mc.thePlayer.posX;
        double dy = (target.posY + target.getEyeHeight() * 0.9)
                  - (mc.thePlayer.posY + mc.thePlayer.getEyeHeight());
        double dz = target.posZ - mc.thePlayer.posZ;

        double dist  = MathHelper.sqrt_double(dx * dx + dz * dz);
        float  yaw   = (float)(Math.toDegrees(Math.atan2(dz, dx))) - 90f;
        float  pitch = (float)(-Math.toDegrees(Math.atan2(dy, dist)));

        return new float[]{yaw, pitch};
    }

    // ── Helpers ────────────────────────────────────────────────────────────

    public static float wrapDegrees(float d) {
        d %= 360f;
        if (d >= 180f)  d -= 360f;
        if (d < -180f)  d += 360f;
        return d;
    }

    public static float getYawDifference(float yaw1, float yaw2) {
        return Math.abs(wrapDegrees(yaw1 - yaw2));
    }
}
